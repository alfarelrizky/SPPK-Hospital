###################
What is Frontdesk App
###################

Frontdesk App adalah sebuah aplikasi yang memiliki peranan penting di dalam building manajemen. Frontdesk App memiliki fitur unggulan antara lain:


1. Manajemen Log Book
2. Pemesanan Ruang Meeting
3. Pemesanan Makanan dan Minuman

*******************
Release Information
*******************

This project just started, stable release will be announce later.

***************
Acknowledgement
***************

The Frontdesk App contributor team:


1. Muhammad Aushafy Setyawan
2. Rizky Subagia 
3. Arga Hutama
4. Alfarel Rizky Izrulliyanto
5. Aditya Pradana
